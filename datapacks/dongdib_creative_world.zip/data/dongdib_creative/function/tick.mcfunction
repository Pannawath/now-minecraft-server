# Handle players in creative world
execute as @a in multiworld:creative run function dongdib_creative:player_in_creative
