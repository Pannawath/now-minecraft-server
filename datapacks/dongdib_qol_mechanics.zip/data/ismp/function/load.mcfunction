# iSMP Load Function
scoreboard objectives add ismp_dummy dummy
scoreboard objectives add sr_leave minecraft.custom:minecraft.leave_game
scoreboard objectives add sr_prev dummy
scoreboard objectives add sr_timer dummy
scoreboard objectives add help trigger
execute as @a run scoreboard players enable @s help
tellraw @a {"text":"[iSMP Mechanics] Loaded successfully!","color":"green"}
