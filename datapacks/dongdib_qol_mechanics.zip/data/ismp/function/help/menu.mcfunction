# Help Trigger Menu Dispatcher
execute if score @s help matches 1 run function ismp:help/page1
execute if score @s help matches 2 run function ismp:help/page2
execute if score @s help matches 3 run function ismp:help/page3
execute if score @s help matches 4 run function ismp:help/page4
execute unless score @s help matches 1..4 run function ismp:help/page1
scoreboard players set @s help 0
scoreboard players enable @s help
