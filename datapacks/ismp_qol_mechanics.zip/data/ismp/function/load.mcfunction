# iSMP Load Function
scoreboard objectives add ismp_dummy dummy
tellraw @a {"text":"[iSMP Mechanics] Loaded successfully!","color":"green"}

gamerule playersSleepingPercentage 1
