# iSMP QoL Tick Function
# 1. Remove Trash Zombies in deep caves holding items
execute as @e[type=zombie,y=-64,dy=100] at @s if entity @s[nbt={CanPickUpLoot:1b}] run tp @s ~ -500 ~

# 2. Water creatures keep air
execute as @e[type=#minecraft:aquatic] run data merge entity @s {Air:300s}

# 3. Name tag special commands
execute as @e[name="_silent"] run data merge entity @s {Silent:1b,CustomName:'""'}
execute as @e[name="_baby"] run data merge entity @s {Age:-2147483648,IsBaby:1b,CustomName:'""'}
execute as @e[name="_show"] run data merge entity @s {CustomNameVisible:1b,CustomName:'""'}
execute as @e[name="_clear"] run data merge entity @s {CustomNameVisible:0b,CustomName:'""'}

