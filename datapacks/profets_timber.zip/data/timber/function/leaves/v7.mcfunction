execute if score #blocks timber.data >= #max_blocks timber.config run return 0
function timber:leaves/take
