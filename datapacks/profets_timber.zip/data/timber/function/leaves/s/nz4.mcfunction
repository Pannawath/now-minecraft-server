scoreboard players remove #cz timber.data 1
function timber:leaves/v4
scoreboard players add #cz timber.data 1
