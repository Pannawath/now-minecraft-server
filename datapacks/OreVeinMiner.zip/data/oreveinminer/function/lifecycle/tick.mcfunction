function oreveinminer:player/tick
execute if score #enabled ovm.config matches 0 run return run function oreveinminer:lifecycle/disabled_tick
execute as @a[gamemode=survival,scores={ovm.player=1}] at @s run function oreveinminer:detection/scan_player
execute as @a[gamemode=survival,scores={ovm.player=1}] at @s run function oreveinminer:operation/process_player
execute if score #activation ovm.config matches 1 as @a[gamemode=survival,tag=ovm.sneaking,scores={ovm.player=1,ovm.run=0}] at @s if items entity @s weapon.mainhand #oreveinminer:valid_tools run function oreveinminer:detection/track
execute if score #activation ovm.config matches 0 as @a[gamemode=survival,scores={ovm.player=1,ovm.run=0}] at @s if items entity @s weapon.mainhand #oreveinminer:valid_tools run function oreveinminer:detection/track
