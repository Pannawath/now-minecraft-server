execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=ovm.owned]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=ovm.owned]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=ovm.owned]
execute as @a at @s run kill @e[type=minecraft:marker,tag=ovm.owned]
scoreboard players set @a ovm.run 0
