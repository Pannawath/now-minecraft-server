scoreboard objectives add ovm.config dummy
scoreboard objectives add ovm.player dummy
scoreboard objectives add ovm.owner dummy
scoreboard objectives add ovm.work dummy
scoreboard objectives add ovm.runtime dummy
scoreboard objectives add ovm.run dummy
scoreboard objectives add ovm.allow dummy
scoreboard objectives add ovm.toggle trigger
scoreboard objectives add ovm.sneak minecraft.custom:minecraft.sneak_time
scoreboard objectives add ovm.sneak_prev dummy
scoreboard objectives add ovm.m_coal minecraft.mined:minecraft.coal_ore
scoreboard objectives add ovm.m_dcoal minecraft.mined:minecraft.deepslate_coal_ore
scoreboard objectives add ovm.m_copper minecraft.mined:minecraft.copper_ore
scoreboard objectives add ovm.m_dcopper minecraft.mined:minecraft.deepslate_copper_ore
scoreboard objectives add ovm.m_diamond minecraft.mined:minecraft.diamond_ore
scoreboard objectives add ovm.m_ddiamond minecraft.mined:minecraft.deepslate_diamond_ore
scoreboard objectives add ovm.m_emerald minecraft.mined:minecraft.emerald_ore
scoreboard objectives add ovm.m_demerald minecraft.mined:minecraft.deepslate_emerald_ore
scoreboard objectives add ovm.m_gold minecraft.mined:minecraft.gold_ore
scoreboard objectives add ovm.m_dgold minecraft.mined:minecraft.deepslate_gold_ore
scoreboard objectives add ovm.m_iron minecraft.mined:minecraft.iron_ore
scoreboard objectives add ovm.m_diron minecraft.mined:minecraft.deepslate_iron_ore
scoreboard objectives add ovm.m_lapis minecraft.mined:minecraft.lapis_ore
scoreboard objectives add ovm.m_dlapis minecraft.mined:minecraft.deepslate_lapis_ore
scoreboard objectives add ovm.m_redstone minecraft.mined:minecraft.redstone_ore
scoreboard objectives add ovm.m_dredstone minecraft.mined:minecraft.deepslate_redstone_ore
scoreboard objectives add ovm.m_ngold minecraft.mined:minecraft.nether_gold_ore
scoreboard objectives add ovm.m_quartz minecraft.mined:minecraft.nether_quartz_ore
scoreboard objectives add ovm.m_debris minecraft.mined:minecraft.ancient_debris
execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=ovm.owned]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=ovm.owned]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=ovm.owned]
execute as @a at @s run kill @e[type=minecraft:marker,tag=ovm.owned]
scoreboard players set @a ovm.run 0
execute unless score #installed ovm.config matches 1 run function oreveinminer:lifecycle/install
execute unless score #schema ovm.config matches 3 run function oreveinminer:lifecycle/migrate_v3
execute unless score #enabled ovm.config matches 0..1 run scoreboard players set #enabled ovm.config 1
execute unless score #activation ovm.config matches 0..1 run scoreboard players set #activation ovm.config 1
execute unless score #max ovm.config matches 1..512 run scoreboard players set #max ovm.config 128
execute unless score #durability ovm.config matches 0..1 run scoreboard players set #durability ovm.config 1
execute unless score #safety ovm.config matches 0..1 run scoreboard players set #safety ovm.config 0
execute unless score #debug ovm.config matches 0..1 run scoreboard players set #debug ovm.config 0
execute unless score #budget ovm.config matches 1..64 run scoreboard players set #budget ovm.config 16
execute unless score #adjacency ovm.config matches 6 unless score #adjacency ovm.config matches 26 run scoreboard players set #adjacency ovm.config 26
scoreboard players set #installed ovm.config 1
scoreboard players set #schema ovm.config 3
