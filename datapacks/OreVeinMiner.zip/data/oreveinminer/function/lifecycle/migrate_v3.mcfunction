scoreboard objectives remove ovm.family
scoreboard players set @a ovm.run 0
scoreboard players set #budget ovm.config 16
scoreboard players set #adjacency ovm.config 26
scoreboard players set #schema ovm.config 3
