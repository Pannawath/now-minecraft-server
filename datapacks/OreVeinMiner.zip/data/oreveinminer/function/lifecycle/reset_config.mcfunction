scoreboard players set #enabled ovm.config 1
scoreboard players set #activation ovm.config 1
scoreboard players set #max ovm.config 128
scoreboard players set #durability ovm.config 1
scoreboard players set #safety ovm.config 0
scoreboard players set #debug ovm.config 0
scoreboard players set #budget ovm.config 16
scoreboard players set #adjacency ovm.config 26
tellraw @s {"text":"OreVeinMiner configuration reset.","color":"green"}
