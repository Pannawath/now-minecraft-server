execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=ovm.owned]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=ovm.owned]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=ovm.owned]
execute as @a at @s run kill @e[type=minecraft:marker,tag=ovm.owned]
data remove storage oreveinminer:runtime target
data remove storage oreveinminer:runtime owner
tag @a remove ovm.actor
tag @a remove ovm.sneaking
tellraw @s {"text":"OreVeinMiner runtime data removed. Disable or remove the datapack before reloading.","color":"yellow"}
scoreboard objectives remove ovm.m_debris
scoreboard objectives remove ovm.m_quartz
scoreboard objectives remove ovm.m_ngold
scoreboard objectives remove ovm.m_dredstone
scoreboard objectives remove ovm.m_redstone
scoreboard objectives remove ovm.m_dlapis
scoreboard objectives remove ovm.m_lapis
scoreboard objectives remove ovm.m_diron
scoreboard objectives remove ovm.m_iron
scoreboard objectives remove ovm.m_dgold
scoreboard objectives remove ovm.m_gold
scoreboard objectives remove ovm.m_demerald
scoreboard objectives remove ovm.m_emerald
scoreboard objectives remove ovm.m_ddiamond
scoreboard objectives remove ovm.m_diamond
scoreboard objectives remove ovm.m_dcopper
scoreboard objectives remove ovm.m_copper
scoreboard objectives remove ovm.m_dcoal
scoreboard objectives remove ovm.m_coal
scoreboard objectives remove ovm.sneak_prev
scoreboard objectives remove ovm.sneak
scoreboard objectives remove ovm.toggle
scoreboard objectives remove ovm.allow
scoreboard objectives remove ovm.run
scoreboard objectives remove ovm.runtime
scoreboard objectives remove ovm.work
scoreboard objectives remove ovm.family
scoreboard objectives remove ovm.owner
scoreboard objectives remove ovm.player
scoreboard objectives remove ovm.config
