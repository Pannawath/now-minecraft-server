scoreboard players set #harvest ovm.runtime 1
execute if items entity @s weapon.mainhand #oreveinminer:tool_tier/wooden if block ~ ~ ~ #minecraft:incorrect_for_wooden_tool run scoreboard players set #harvest ovm.runtime 0
execute if items entity @s weapon.mainhand #oreveinminer:tool_tier/gold if block ~ ~ ~ #minecraft:incorrect_for_gold_tool run scoreboard players set #harvest ovm.runtime 0
execute if items entity @s weapon.mainhand #oreveinminer:tool_tier/stone if block ~ ~ ~ #minecraft:incorrect_for_stone_tool run scoreboard players set #harvest ovm.runtime 0
execute if items entity @s weapon.mainhand #oreveinminer:tool_tier/copper if block ~ ~ ~ #oreveinminer:incorrect_for_copper_tool run scoreboard players set #harvest ovm.runtime 0
execute if items entity @s weapon.mainhand #oreveinminer:tool_tier/iron if block ~ ~ ~ #minecraft:incorrect_for_iron_tool run scoreboard players set #harvest ovm.runtime 0
execute if items entity @s weapon.mainhand #oreveinminer:tool_tier/diamond if block ~ ~ ~ #minecraft:incorrect_for_diamond_tool run scoreboard players set #harvest ovm.runtime 0
execute if items entity @s weapon.mainhand #oreveinminer:tool_tier/netherite if block ~ ~ ~ #minecraft:incorrect_for_netherite_tool run scoreboard players set #harvest ovm.runtime 0
