execute store result score #owner ovm.runtime run data get entity @s data.owner
scoreboard players set #ready ovm.runtime 0
execute as @a[gamemode=survival,scores={ovm.player=1,ovm.run=0}] if score @s ovm.owner = #owner ovm.runtime if items entity @s weapon.mainhand #oreveinminer:valid_tools run scoreboard players set #ready ovm.runtime 1
execute if score #ready ovm.runtime matches 0 run return run kill @s
tag @s remove ovm.target
tag @s add ovm.operation
data modify entity @s data.frontier set value []
data modify entity @s data.head set value 0
data remove entity @s data.cursor
execute as @a if score @s ovm.owner = #owner ovm.runtime run scoreboard players set @s ovm.work 0
execute as @a if score @s ovm.owner = #owner ovm.runtime run scoreboard players set @s ovm.run 1
execute as @a if score @s ovm.owner = #owner ovm.runtime run function oreveinminer:debug/start
function oreveinminer:queue/enqueue_neighbors
