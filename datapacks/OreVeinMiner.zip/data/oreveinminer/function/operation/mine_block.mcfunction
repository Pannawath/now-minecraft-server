execute if score #safety ovm.config matches 1 if items entity @s weapon.mainhand *[minecraft:damage~{durability:{max:1}}] unless items entity @s weapon.mainhand *[minecraft:unbreakable] run scoreboard players set #safety_stop ovm.runtime 1
execute if score #safety_stop ovm.runtime matches 1 run return 0
scoreboard players set @s ovm.allow 1
function #oreveinminer:hooks/before_remove
execute if score @s ovm.allow matches 0 run return 0
loot spawn ~0.5 ~0.5 ~0.5 mine ~ ~ ~ mainhand
execute unless items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"minecraft:silk_touch",levels:{min:1}}]] run function oreveinminer:xp/dispatch
setblock ~ ~ ~ minecraft:air
scoreboard players add @s ovm.work 1
function #oreveinminer:hooks/after_remove
execute if score #durability ovm.config matches 1 run function #oreveinminer:hooks/damage_tool
execute if items entity @s weapon.mainhand #oreveinminer:valid_tools as @e[type=minecraft:marker,tag=ovm.processing,limit=1] run function oreveinminer:queue/enqueue_neighbors
function oreveinminer:debug/block
