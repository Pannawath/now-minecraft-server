$execute as @e[type=minecraft:marker,tag=ovm.operation,tag=ovm.owner.$(value),limit=1] at @s run function oreveinminer:operation/process
$execute unless entity @e[type=minecraft:marker,tag=ovm.operation,tag=ovm.owner.$(value),limit=1] if score @s ovm.run matches 1 run scoreboard players set @s ovm.run 0
