execute store result score #owner ovm.runtime run data get entity @s data.owner
scoreboard players set #ready ovm.runtime 0
execute as @e[tag=ovm.actor,scores={ovm.player=1,ovm.run=1}] if score @s ovm.owner = #owner ovm.runtime run scoreboard players set #ready ovm.runtime 1
execute if score #ready ovm.runtime matches 0 run return run kill @s
scoreboard players operation #budget ovm.runtime = #budget ovm.config
tag @s add ovm.processing
function oreveinminer:queue/drain
execute if entity @s run tag @s remove ovm.processing
