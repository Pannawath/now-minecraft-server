$execute if block ~ ~ ~ #$(match) run function oreveinminer:operation/claim
