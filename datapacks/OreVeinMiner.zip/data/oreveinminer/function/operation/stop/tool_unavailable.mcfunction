execute store result score #owner ovm.runtime run data get entity @s data.owner
execute as @e[tag=ovm.actor] if score @s ovm.owner = #owner ovm.runtime run scoreboard players set @s ovm.run 0
execute as @e[tag=ovm.actor] if score @s ovm.owner = #owner ovm.runtime run function oreveinminer:debug/tool_unavailable
kill @s
