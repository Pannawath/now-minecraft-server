execute store result score #owner ovm.runtime run data get entity @s data.owner
scoreboard players set #ready ovm.runtime 0
execute as @e[tag=ovm.actor,scores={ovm.player=1,ovm.run=1}] if score @s ovm.owner = #owner ovm.runtime if items entity @s weapon.mainhand #oreveinminer:valid_tools run scoreboard players set #ready ovm.runtime 1
execute if score #ready ovm.runtime matches 0 run return run function oreveinminer:operation/stop/tool_unavailable
scoreboard players set #harvest ovm.runtime 0
execute as @e[tag=ovm.actor] if score @s ovm.owner = #owner ovm.runtime run function oreveinminer:utility/check_harvest
execute if score #harvest ovm.runtime matches 0 run return 0
scoreboard players set #limit ovm.runtime 0
execute as @e[tag=ovm.actor] if score @s ovm.owner = #owner ovm.runtime if score @s ovm.work >= #max ovm.config run scoreboard players set #limit ovm.runtime 1
execute if score #limit ovm.runtime matches 1 run return run function oreveinminer:operation/stop/max_reached
scoreboard players set #safety_stop ovm.runtime 0
execute as @e[tag=ovm.actor] if score @s ovm.owner = #owner ovm.runtime run function oreveinminer:operation/mine_block
execute if score #safety_stop ovm.runtime matches 1 run return run function oreveinminer:operation/stop/tool_safety
scoreboard players set #ready ovm.runtime 0
execute as @e[tag=ovm.actor] if score @s ovm.owner = #owner ovm.runtime if score @s ovm.run matches 1 if items entity @s weapon.mainhand #oreveinminer:valid_tools run scoreboard players set #ready ovm.runtime 1
execute if score #ready ovm.runtime matches 0 run return run function oreveinminer:operation/stop/tool_unavailable
