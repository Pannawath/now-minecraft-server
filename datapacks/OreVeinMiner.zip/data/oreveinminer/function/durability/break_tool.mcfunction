item replace entity @s weapon.mainhand with minecraft:air
playsound minecraft:entity.item.break player @s ~ ~ ~ 1 1
