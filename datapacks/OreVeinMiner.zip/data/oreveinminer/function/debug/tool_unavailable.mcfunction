execute unless score #debug ovm.config matches 1 run return 0
tellraw @s {"text":"[OreVeinMiner] Stopped because the tool is unavailable.","color":"gold"}
