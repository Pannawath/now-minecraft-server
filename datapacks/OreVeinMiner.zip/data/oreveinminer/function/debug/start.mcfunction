execute unless score #debug ovm.config matches 1 run return 0
tellraw @s {"text":"[OreVeinMiner] Vein operation started.","color":"gray"}
