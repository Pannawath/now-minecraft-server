execute unless score #debug ovm.config matches 1 run return 0
tellraw @s [{"text":"[OreVeinMiner] Processed block ","color":"dark_gray"},{"score":{"name":"@s","objective":"ovm.work"},"color":"gray"}]
