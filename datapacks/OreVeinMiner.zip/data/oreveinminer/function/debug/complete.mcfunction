execute unless score #debug ovm.config matches 1 run return 0
tellraw @s [{"text":"[OreVeinMiner] Complete: ","color":"gray"},{"score":{"name":"@s","objective":"ovm.work"},"color":"white"},{"text":" additional blocks.","color":"gray"}]
