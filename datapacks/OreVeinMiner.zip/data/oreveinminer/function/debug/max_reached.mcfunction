execute unless score #debug ovm.config matches 1 run return 0
tellraw @s {"text":"[OreVeinMiner] Stopped at the configured vein limit.","color":"gold"}
