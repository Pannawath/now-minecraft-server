scoreboard players set #activation ovm.config 0
tellraw @s {"text":"OreVeinMiner no longer requires crouching.","color":"yellow"}
