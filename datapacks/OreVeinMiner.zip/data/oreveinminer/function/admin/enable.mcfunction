scoreboard players set #enabled ovm.config 1
tellraw @s {"text":"OreVeinMiner globally enabled.","color":"green"}
