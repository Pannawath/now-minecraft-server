scoreboard players set #safety ovm.config 1
tellraw @s {"text":"OreVeinMiner tool-break protection enabled.","color":"green"}
