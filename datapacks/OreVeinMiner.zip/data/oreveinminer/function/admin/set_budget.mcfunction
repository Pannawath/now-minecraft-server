$scoreboard players set #budget ovm.config $(value)
scoreboard players set #valid ovm.runtime 0
execute if score #budget ovm.config matches 1..64 run scoreboard players set #valid ovm.runtime 1
execute if score #valid ovm.runtime matches 0 run scoreboard players set #budget ovm.config 16
execute if score #valid ovm.runtime matches 0 run tellraw @s {"text":"Invalid budget; restored the default of 16 queue visits per tick.","color":"red"}
execute if score #valid ovm.runtime matches 1 run tellraw @s [{"text":"OreVeinMiner budget set to ","color":"green"},{"score":{"name":"#budget","objective":"ovm.config"}},{"text":" queue visits per tick.","color":"green"}]
