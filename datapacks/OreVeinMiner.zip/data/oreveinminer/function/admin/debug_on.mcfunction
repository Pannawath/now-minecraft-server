scoreboard players set #debug ovm.config 1
tellraw @s {"text":"OreVeinMiner debug output enabled.","color":"green"}
