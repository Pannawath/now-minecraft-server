scoreboard players set #adjacency ovm.config 26
tellraw @s {"text":"OreVeinMiner adjacency set to all 26 immediate neighbors.","color":"green"}
