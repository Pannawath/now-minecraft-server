scoreboard players set #enabled ovm.config 0
execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=ovm.owned]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=ovm.owned]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=ovm.owned]
execute as @a at @s run kill @e[type=minecraft:marker,tag=ovm.owned]
scoreboard players set @a ovm.run 0
tellraw @s {"text":"OreVeinMiner globally disabled.","color":"yellow"}
