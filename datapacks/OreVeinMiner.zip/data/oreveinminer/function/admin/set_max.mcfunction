$scoreboard players set #max ovm.config $(value)
scoreboard players set #valid ovm.work 0
execute if score #max ovm.config matches 1..512 run scoreboard players set #valid ovm.work 1
execute if score #valid ovm.work matches 0 run scoreboard players set #max ovm.config 128
execute if score #valid ovm.work matches 0 run tellraw @s {"text":"Invalid limit; restored the default of 128.","color":"red"}
execute if score #valid ovm.work matches 1 run tellraw @s [{"text":"OreVeinMiner limit set to ","color":"green"},{"score":{"name":"#max","objective":"ovm.config"}},{"text":" additional blocks.","color":"green"}]
