scoreboard players set #activation ovm.config 1
tellraw @s {"text":"OreVeinMiner now requires crouching.","color":"green"}
