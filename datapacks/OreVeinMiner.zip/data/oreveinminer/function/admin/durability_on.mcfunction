scoreboard players set #durability ovm.config 1
tellraw @s {"text":"OreVeinMiner per-block durability enabled.","color":"green"}
