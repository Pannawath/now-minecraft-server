scoreboard players set #safety ovm.config 0
tellraw @s {"text":"OreVeinMiner tool-break protection disabled.","color":"yellow"}
