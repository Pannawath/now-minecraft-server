scoreboard players set #debug ovm.config 0
tellraw @s {"text":"OreVeinMiner debug output disabled.","color":"yellow"}
