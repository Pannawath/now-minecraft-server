scoreboard players set #adjacency ovm.config 6
tellraw @s {"text":"OreVeinMiner adjacency set to six shared faces.","color":"green"}
