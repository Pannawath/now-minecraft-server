scoreboard players set #durability ovm.config 0
tellraw @s {"text":"OreVeinMiner per-block durability disabled.","color":"yellow"}
