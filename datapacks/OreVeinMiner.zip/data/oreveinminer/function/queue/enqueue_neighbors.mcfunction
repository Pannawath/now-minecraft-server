function oreveinminer:queue/enqueue_faces
execute if score #adjacency ovm.config matches 26 run function oreveinminer:queue/enqueue_diagonals
function #oreveinminer:hooks/enqueue_extra
