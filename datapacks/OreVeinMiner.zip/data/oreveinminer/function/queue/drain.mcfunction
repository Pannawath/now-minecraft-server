execute unless entity @s[tag=ovm.operation] run return 0
function oreveinminer:queue/load_next with entity @s data
execute unless entity @s run return 0
execute store result score #head ovm.runtime run data get entity @s data.head
scoreboard players add #head ovm.runtime 1
execute store result entity @s data.head int 1 run scoreboard players get #head ovm.runtime
function oreveinminer:queue/visit with entity @s data.cursor
scoreboard players remove #budget ovm.runtime 1
execute if score #budget ovm.runtime matches 1.. if entity @s[tag=ovm.operation] run function oreveinminer:queue/drain
