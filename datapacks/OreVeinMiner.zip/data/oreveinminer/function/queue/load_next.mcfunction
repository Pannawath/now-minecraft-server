$execute unless data entity @s data.frontier[$(head)] run return run function oreveinminer:operation/complete
$data modify entity @s data.cursor set from entity @s data.frontier[$(head)]
