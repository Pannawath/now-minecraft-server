execute positioned ~1 ~ ~ run function oreveinminer:queue/enqueue_here
execute positioned ~-1 ~ ~ run function oreveinminer:queue/enqueue_here
execute positioned ~ ~1 ~ run function oreveinminer:queue/enqueue_here
execute positioned ~ ~-1 ~ run function oreveinminer:queue/enqueue_here
execute positioned ~ ~ ~1 run function oreveinminer:queue/enqueue_here
execute positioned ~ ~ ~-1 run function oreveinminer:queue/enqueue_here
