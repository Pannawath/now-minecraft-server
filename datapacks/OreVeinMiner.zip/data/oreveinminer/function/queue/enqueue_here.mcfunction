function oreveinminer:queue/enqueue_match with entity @s data
