# Twelve edge neighbors
execute positioned ~1 ~1 ~ run function oreveinminer:queue/enqueue_here
execute positioned ~1 ~-1 ~ run function oreveinminer:queue/enqueue_here
execute positioned ~-1 ~1 ~ run function oreveinminer:queue/enqueue_here
execute positioned ~-1 ~-1 ~ run function oreveinminer:queue/enqueue_here
execute positioned ~1 ~ ~1 run function oreveinminer:queue/enqueue_here
execute positioned ~1 ~ ~-1 run function oreveinminer:queue/enqueue_here
execute positioned ~-1 ~ ~1 run function oreveinminer:queue/enqueue_here
execute positioned ~-1 ~ ~-1 run function oreveinminer:queue/enqueue_here
execute positioned ~ ~1 ~1 run function oreveinminer:queue/enqueue_here
execute positioned ~ ~1 ~-1 run function oreveinminer:queue/enqueue_here
execute positioned ~ ~-1 ~1 run function oreveinminer:queue/enqueue_here
execute positioned ~ ~-1 ~-1 run function oreveinminer:queue/enqueue_here

# Eight corner neighbors
execute positioned ~1 ~1 ~1 run function oreveinminer:queue/enqueue_here
execute positioned ~1 ~1 ~-1 run function oreveinminer:queue/enqueue_here
execute positioned ~1 ~-1 ~1 run function oreveinminer:queue/enqueue_here
execute positioned ~1 ~-1 ~-1 run function oreveinminer:queue/enqueue_here
execute positioned ~-1 ~1 ~1 run function oreveinminer:queue/enqueue_here
execute positioned ~-1 ~1 ~-1 run function oreveinminer:queue/enqueue_here
execute positioned ~-1 ~-1 ~1 run function oreveinminer:queue/enqueue_here
execute positioned ~-1 ~-1 ~-1 run function oreveinminer:queue/enqueue_here
