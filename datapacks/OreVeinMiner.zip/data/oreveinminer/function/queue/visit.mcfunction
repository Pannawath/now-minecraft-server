$execute positioned $(x) $(y) $(z) run function oreveinminer:operation/dispatch
