$execute if block ~ ~ ~ #$(match) run function oreveinminer:queue/append_here
