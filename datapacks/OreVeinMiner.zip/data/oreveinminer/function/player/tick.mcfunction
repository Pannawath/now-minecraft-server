tag @a add ovm.actor
execute as @a unless score @s ovm.owner matches 1.. run function oreveinminer:player/register
execute as @a unless score @s ovm.player matches 0..1 run scoreboard players set @s ovm.player 1
execute as @a run tag @s remove ovm.sneaking
execute as @a if score @s ovm.sneak > @s ovm.sneak_prev run tag @s add ovm.sneaking
execute as @a run scoreboard players operation @s ovm.sneak_prev = @s ovm.sneak
scoreboard players enable @a ovm.toggle
execute as @a[scores={ovm.toggle=1}] run function oreveinminer:player/enable
execute as @a[scores={ovm.toggle=2}] run function oreveinminer:player/disable
scoreboard players set @a[scores={ovm.toggle=1..}] ovm.toggle 0
