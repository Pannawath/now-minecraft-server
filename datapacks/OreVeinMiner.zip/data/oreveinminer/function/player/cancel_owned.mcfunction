$execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=ovm.owned,tag=ovm.owner.$(value)]
$execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=ovm.owned,tag=ovm.owner.$(value)]
$execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=ovm.owned,tag=ovm.owner.$(value)]
$kill @e[type=minecraft:marker,tag=ovm.owned,tag=ovm.owner.$(value)]
