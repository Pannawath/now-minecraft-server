scoreboard players add #next_id ovm.owner 1
scoreboard players operation @s ovm.owner = #next_id ovm.owner
tag @s add ovm.actor
scoreboard players set @s ovm.player 1
scoreboard players set @s ovm.run 0
scoreboard players set @s ovm.work 0
scoreboard players add @s ovm.sneak 0
scoreboard players operation @s ovm.sneak_prev = @s ovm.sneak
scoreboard players add @s ovm.m_coal 0
scoreboard players add @s ovm.m_dcoal 0
scoreboard players add @s ovm.m_copper 0
scoreboard players add @s ovm.m_dcopper 0
scoreboard players add @s ovm.m_diamond 0
scoreboard players add @s ovm.m_ddiamond 0
scoreboard players add @s ovm.m_emerald 0
scoreboard players add @s ovm.m_demerald 0
scoreboard players add @s ovm.m_gold 0
scoreboard players add @s ovm.m_dgold 0
scoreboard players add @s ovm.m_iron 0
scoreboard players add @s ovm.m_diron 0
scoreboard players add @s ovm.m_lapis 0
scoreboard players add @s ovm.m_dlapis 0
scoreboard players add @s ovm.m_redstone 0
scoreboard players add @s ovm.m_dredstone 0
scoreboard players add @s ovm.m_ngold 0
scoreboard players add @s ovm.m_quartz 0
scoreboard players add @s ovm.m_debris 0
