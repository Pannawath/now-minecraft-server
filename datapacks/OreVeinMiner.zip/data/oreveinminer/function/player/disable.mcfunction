scoreboard players set @s ovm.player 0
scoreboard players set @s ovm.run 0
execute store result storage oreveinminer:runtime owner.value int 1 run scoreboard players get @s ovm.owner
function oreveinminer:player/cancel_owned with storage oreveinminer:runtime owner
tellraw @s {"text":"OreVeinMiner disabled for you. Use /trigger ovm.toggle set 1 to re-enable it.","color":"yellow"}
