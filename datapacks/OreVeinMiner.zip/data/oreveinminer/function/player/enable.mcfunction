scoreboard players set @s ovm.player 1
tellraw @s {"text":"OreVeinMiner enabled for you.","color":"green"}
