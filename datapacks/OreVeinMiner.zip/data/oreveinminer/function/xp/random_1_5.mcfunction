execute store result score #xp ovm.runtime run random value 1..5
execute if score #xp ovm.runtime matches 1 run summon minecraft:experience_orb ~0.5 ~0.5 ~0.5 {Count:1,Value:1}
execute if score #xp ovm.runtime matches 2 run summon minecraft:experience_orb ~0.5 ~0.5 ~0.5 {Count:1,Value:2}
execute if score #xp ovm.runtime matches 3 run summon minecraft:experience_orb ~0.5 ~0.5 ~0.5 {Count:1,Value:3}
execute if score #xp ovm.runtime matches 4 run summon minecraft:experience_orb ~0.5 ~0.5 ~0.5 {Count:1,Value:4}
execute if score #xp ovm.runtime matches 5 run summon minecraft:experience_orb ~0.5 ~0.5 ~0.5 {Count:1,Value:5}
