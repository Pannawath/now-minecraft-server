execute if block ~ ~ ~ #oreveinminer:family/coal run function oreveinminer:xp/random_0_2
execute if block ~ ~ ~ #oreveinminer:family/diamond run function oreveinminer:xp/random_3_7
execute if block ~ ~ ~ #oreveinminer:family/emerald run function oreveinminer:xp/random_3_7
execute if block ~ ~ ~ #oreveinminer:family/lapis run function oreveinminer:xp/random_2_5
execute if block ~ ~ ~ #oreveinminer:family/redstone run function oreveinminer:xp/random_1_5
execute if block ~ ~ ~ #oreveinminer:family/nether_gold run function oreveinminer:xp/random_0_1
execute if block ~ ~ ~ #oreveinminer:family/quartz run function oreveinminer:xp/random_2_5
