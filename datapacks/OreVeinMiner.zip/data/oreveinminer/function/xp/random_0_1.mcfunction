execute store result score #xp ovm.runtime run random value 0..1
execute if score #xp ovm.runtime matches 1 run summon minecraft:experience_orb ~0.5 ~0.5 ~0.5 {Count:1,Value:1}
