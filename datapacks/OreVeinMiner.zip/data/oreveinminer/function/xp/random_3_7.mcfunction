execute store result score #xp ovm.runtime run random value 3..7
execute if score #xp ovm.runtime matches 3 run summon minecraft:experience_orb ~0.5 ~0.5 ~0.5 {Count:1,Value:3}
execute if score #xp ovm.runtime matches 4 run summon minecraft:experience_orb ~0.5 ~0.5 ~0.5 {Count:1,Value:4}
execute if score #xp ovm.runtime matches 5 run summon minecraft:experience_orb ~0.5 ~0.5 ~0.5 {Count:1,Value:5}
execute if score #xp ovm.runtime matches 6 run summon minecraft:experience_orb ~0.5 ~0.5 ~0.5 {Count:1,Value:6}
execute if score #xp ovm.runtime matches 7 run summon minecraft:experience_orb ~0.5 ~0.5 ~0.5 {Count:1,Value:7}
