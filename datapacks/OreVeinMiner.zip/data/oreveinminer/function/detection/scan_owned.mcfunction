$execute as @e[type=minecraft:marker,tag=ovm.target,tag=ovm.owner.$(value),limit=1] at @s run function oreveinminer:detection/evaluate_target
