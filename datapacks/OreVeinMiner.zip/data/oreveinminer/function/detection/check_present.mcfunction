$execute if block ~ ~ ~ #$(match) run scoreboard players set #present ovm.runtime 1
