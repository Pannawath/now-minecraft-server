execute store result score #owner ovm.runtime run data get entity @s data.owner
execute store result score #block ovm.runtime run data get entity @s data.block
execute store result score #baseline ovm.runtime run data get entity @s data.baseline
execute store result score #seen ovm.runtime run data get entity @s data.seen
execute store result score #now ovm.runtime run time query gametime
scoreboard players operation #age ovm.runtime = #now ovm.runtime
scoreboard players operation #age ovm.runtime -= #seen ovm.runtime
scoreboard players set #near ovm.runtime 0
execute as @a[gamemode=survival,distance=..8,scores={ovm.player=1}] if score @s ovm.owner = #owner ovm.runtime if items entity @s weapon.mainhand #oreveinminer:valid_tools run scoreboard players set #near ovm.runtime 1
execute if score #near ovm.runtime matches 0 run return run kill @s
scoreboard players set #present ovm.runtime 0
function oreveinminer:detection/check_present with entity @s data
scoreboard players set #event ovm.runtime 0
execute if score #block ovm.runtime matches 0 if score #present ovm.runtime matches 0 run scoreboard players set #event ovm.runtime 1
execute if score #block ovm.runtime matches 1.. run function oreveinminer:detection/verify_mined_stat
execute if score #event ovm.runtime matches 1 if score #present ovm.runtime matches 1 run return run kill @s
execute if score #event ovm.runtime matches 1 if score #present ovm.runtime matches 0 run return run function oreveinminer:operation/start
execute if score #present ovm.runtime matches 0 run return run kill @s
execute if score #age ovm.runtime matches 6.. run return run kill @s
