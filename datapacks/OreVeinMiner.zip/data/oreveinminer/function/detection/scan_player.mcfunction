execute store result storage oreveinminer:runtime owner.value int 1 run scoreboard players get @s ovm.owner
function oreveinminer:detection/scan_owned with storage oreveinminer:runtime owner
