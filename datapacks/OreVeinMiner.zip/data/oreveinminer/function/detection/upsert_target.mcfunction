$execute as @e[type=minecraft:marker,tag=ovm.target,tag=ovm.owner.$(owner),limit=1] run tp @s ~ ~ ~
$execute as @e[type=minecraft:marker,tag=ovm.target,tag=ovm.owner.$(owner),limit=1] run data merge entity @s {data:{source:"oreveinminer",owner:$(owner),family:$(family),match:"$(match)",block:$(block),baseline:$(baseline),seen:$(seen)}}
$execute unless entity @e[type=minecraft:marker,tag=ovm.target,tag=ovm.owner.$(owner),limit=1] summon minecraft:marker run function oreveinminer:detection/create_target with storage oreveinminer:runtime target
