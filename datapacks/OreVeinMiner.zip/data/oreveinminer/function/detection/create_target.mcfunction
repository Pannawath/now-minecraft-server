tag @s add ovm.owned
tag @s add ovm.target
$tag @s add ovm.owner.$(owner)
$data merge entity @s {data:{source:"oreveinminer",owner:$(owner),family:$(family),match:"$(match)",block:$(block),baseline:$(baseline),seen:$(seen)}}
