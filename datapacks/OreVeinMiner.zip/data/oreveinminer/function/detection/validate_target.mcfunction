function oreveinminer:utility/check_harvest
execute if score #harvest ovm.runtime matches 1 align xyz run function oreveinminer:detection/acquire_target
