scoreboard players set #ray ovm.runtime 0
execute anchored eyes positioned ^ ^ ^0.25 run function oreveinminer:detection/ray_step
