scoreboard players set #family ovm.runtime 0
execute if block ~ ~ ~ #oreveinminer:family/coal run scoreboard players set #family ovm.runtime 1
execute if block ~ ~ ~ #oreveinminer:family/copper run scoreboard players set #family ovm.runtime 2
execute if block ~ ~ ~ #oreveinminer:family/diamond run scoreboard players set #family ovm.runtime 3
execute if block ~ ~ ~ #oreveinminer:family/emerald run scoreboard players set #family ovm.runtime 4
execute if block ~ ~ ~ #oreveinminer:family/gold run scoreboard players set #family ovm.runtime 5
execute if block ~ ~ ~ #oreveinminer:family/iron run scoreboard players set #family ovm.runtime 6
execute if block ~ ~ ~ #oreveinminer:family/lapis run scoreboard players set #family ovm.runtime 7
execute if block ~ ~ ~ #oreveinminer:family/redstone run scoreboard players set #family ovm.runtime 8
execute if block ~ ~ ~ #oreveinminer:family/nether_gold run scoreboard players set #family ovm.runtime 9
execute if block ~ ~ ~ #oreveinminer:family/quartz run scoreboard players set #family ovm.runtime 10
execute if block ~ ~ ~ #oreveinminer:family/ancient_debris run scoreboard players set #family ovm.runtime 11
scoreboard players set #block ovm.runtime 0
execute if block ~ ~ ~ minecraft:coal_ore run scoreboard players set #block ovm.runtime 1
execute if block ~ ~ ~ minecraft:deepslate_coal_ore run scoreboard players set #block ovm.runtime 2
execute if block ~ ~ ~ minecraft:copper_ore run scoreboard players set #block ovm.runtime 3
execute if block ~ ~ ~ minecraft:deepslate_copper_ore run scoreboard players set #block ovm.runtime 4
execute if block ~ ~ ~ minecraft:diamond_ore run scoreboard players set #block ovm.runtime 5
execute if block ~ ~ ~ minecraft:deepslate_diamond_ore run scoreboard players set #block ovm.runtime 6
execute if block ~ ~ ~ minecraft:emerald_ore run scoreboard players set #block ovm.runtime 7
execute if block ~ ~ ~ minecraft:deepslate_emerald_ore run scoreboard players set #block ovm.runtime 8
execute if block ~ ~ ~ minecraft:gold_ore run scoreboard players set #block ovm.runtime 9
execute if block ~ ~ ~ minecraft:deepslate_gold_ore run scoreboard players set #block ovm.runtime 10
execute if block ~ ~ ~ minecraft:iron_ore run scoreboard players set #block ovm.runtime 11
execute if block ~ ~ ~ minecraft:deepslate_iron_ore run scoreboard players set #block ovm.runtime 12
execute if block ~ ~ ~ minecraft:lapis_ore run scoreboard players set #block ovm.runtime 13
execute if block ~ ~ ~ minecraft:deepslate_lapis_ore run scoreboard players set #block ovm.runtime 14
execute if block ~ ~ ~ minecraft:redstone_ore run scoreboard players set #block ovm.runtime 15
execute if block ~ ~ ~ minecraft:deepslate_redstone_ore run scoreboard players set #block ovm.runtime 16
execute if block ~ ~ ~ minecraft:nether_gold_ore run scoreboard players set #block ovm.runtime 17
execute if block ~ ~ ~ minecraft:nether_quartz_ore run scoreboard players set #block ovm.runtime 18
execute if block ~ ~ ~ minecraft:ancient_debris run scoreboard players set #block ovm.runtime 19
scoreboard players set #baseline ovm.runtime 0
execute if score #block ovm.runtime matches 1 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_coal
execute if score #block ovm.runtime matches 2 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_dcoal
execute if score #block ovm.runtime matches 3 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_copper
execute if score #block ovm.runtime matches 4 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_dcopper
execute if score #block ovm.runtime matches 5 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_diamond
execute if score #block ovm.runtime matches 6 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_ddiamond
execute if score #block ovm.runtime matches 7 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_emerald
execute if score #block ovm.runtime matches 8 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_demerald
execute if score #block ovm.runtime matches 9 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_gold
execute if score #block ovm.runtime matches 10 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_dgold
execute if score #block ovm.runtime matches 11 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_iron
execute if score #block ovm.runtime matches 12 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_diron
execute if score #block ovm.runtime matches 13 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_lapis
execute if score #block ovm.runtime matches 14 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_dlapis
execute if score #block ovm.runtime matches 15 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_redstone
execute if score #block ovm.runtime matches 16 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_dredstone
execute if score #block ovm.runtime matches 17 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_ngold
execute if score #block ovm.runtime matches 18 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_quartz
execute if score #block ovm.runtime matches 19 run scoreboard players operation #baseline ovm.runtime = @s ovm.m_debris
scoreboard players operation #owner ovm.runtime = @s ovm.owner
execute store result score #seen ovm.runtime run time query gametime
execute store result storage oreveinminer:runtime target.owner int 1 run scoreboard players get #owner ovm.runtime
execute store result storage oreveinminer:runtime target.family int 1 run scoreboard players get #family ovm.runtime
function oreveinminer:detection/set_match
execute store result storage oreveinminer:runtime target.block int 1 run scoreboard players get #block ovm.runtime
execute store result storage oreveinminer:runtime target.baseline int 1 run scoreboard players get #baseline ovm.runtime
execute store result storage oreveinminer:runtime target.seen int 1 run scoreboard players get #seen ovm.runtime
function oreveinminer:detection/upsert_target with storage oreveinminer:runtime target
