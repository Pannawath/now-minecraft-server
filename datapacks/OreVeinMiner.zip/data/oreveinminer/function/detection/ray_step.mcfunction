execute if block ~ ~ ~ #oreveinminer:vein_mineable run return run function oreveinminer:detection/validate_target
execute unless block ~ ~ ~ #minecraft:replaceable run return 0
scoreboard players add #ray ovm.runtime 1
execute if score #ray ovm.runtime matches ..23 positioned ^ ^ ^0.25 run function oreveinminer:detection/ray_step
