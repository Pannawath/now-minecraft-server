effect give @s minecraft:blindness 2 0 true
effect give @s minecraft:darkness 5 0 true
playsound minecraft:entity.warden.roar ambient @s ~ ~ ~ 1.0 0.6
playsound minecraft:entity.elder_guardian.curse ambient @s ~ ~ ~ 0.7 0.5
particle minecraft:sculk_soul ~ ~1.5 ~ 0.5 0.5 0.5 0.05 30