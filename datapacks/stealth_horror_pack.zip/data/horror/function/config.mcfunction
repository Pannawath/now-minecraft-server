# User configurable settings
# Edit config/horror/settings.mcfunction on server or sync via git

scoreboard players set #global horror_interval 360
scoreboard players set #global horror_enabled 1
scoreboard players set #global watcher_duration 160