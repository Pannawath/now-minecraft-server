playsound minecraft:entity.creeper.primed ambient @s ^1 ^ ^-2 0.9 0.8
playsound minecraft:entity.zombie.step ambient @s ^-2 ^ ^-1 1.0 0.7
playsound minecraft:block.wood.step ambient @s ^ ^ ^-3 1.0 0.6