scoreboard players add #global horror_timer 1
scoreboard players add #global horror_rng 1
execute if score #global horror_rng matches 7.. run scoreboard players set #global horror_rng 1

# Watcher lifetime counter & vanish if player approaches
execute as @e[type=armor_stand,tag=horror_watcher] at @s if score @s watcher_life matches 1.. run scoreboard players remove @s watcher_life 1
execute as @e[type=armor_stand,tag=horror_watcher] at @s if score @s watcher_life matches ..0 run function horror:watcher_vanish
execute as @e[type=armor_stand,tag=horror_watcher] at @s if entity @a[distance=..12] run function horror:watcher_vanish

# Trigger horror every 15-20 seconds (360 ticks)
execute if score #global horror_timer matches 360.. run function horror:auto_trigger