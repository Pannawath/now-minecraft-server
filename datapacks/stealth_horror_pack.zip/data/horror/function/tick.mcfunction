# Horror Tick Loop
scoreboard players add #global horror_timer 1
scoreboard players add #global horror_rng 1
execute if score #global horror_rng matches 4.. run scoreboard players set #global horror_rng 1

# Check if any player approaches existing Watcher (< 14 blocks)
execute as @e[type=armor_stand,tag=horror_watcher] at @s if entity @a[distance=..14] run function horror:watcher_vanish

# Auto trigger every ~20 minutes (24000 ticks)
execute if score #global horror_timer matches 24000.. run function horror:auto_trigger
