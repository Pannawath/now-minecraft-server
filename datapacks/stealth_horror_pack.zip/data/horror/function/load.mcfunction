# Horror Engine Initializer
scoreboard objectives add horror_timer dummy
scoreboard objectives add horror_rand dummy
scoreboard players set #global horror_timer 0
