scoreboard objectives add horror_timer dummy
scoreboard objectives add horror_rng dummy
scoreboard objectives add watcher_life dummy
scoreboard players set #global horror_timer 0
scoreboard players set #global horror_rng 1