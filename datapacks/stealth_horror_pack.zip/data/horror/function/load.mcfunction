# Initialize horror scoreboards
scoreboard objectives add horror_timer dummy
scoreboard objectives add horror_rng dummy
scoreboard objectives add watcher_life dummy
scoreboard objectives add horror_interval dummy
scoreboard objectives add horror_enabled dummy
scoreboard objectives add watcher_duration dummy

# Default values if not set
scoreboard players set #global horror_timer 0
scoreboard players set #global horror_rng 1
scoreboard players set #global horror_enabled 1
scoreboard players set #global horror_interval 360
scoreboard players set #global watcher_duration 160

# Load custom user settings from config folder
function horror:config