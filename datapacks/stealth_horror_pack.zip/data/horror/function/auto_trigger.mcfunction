scoreboard players set #global horror_timer 0
execute as @r[gamemode=survival] at @s run function horror:trigger_random