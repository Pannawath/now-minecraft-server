# Reset timer
scoreboard players set #global horror_timer 0

# Pick 1 random survival player
execute as @r[gamemode=survival] at @s run function horror:trigger_random
