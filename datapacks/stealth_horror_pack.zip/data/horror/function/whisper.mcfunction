# Play creepy sound directly into target's ears
playsound minecraft:entity.player.breath ambient @s ~ ~ ~ 0.8 0.6
playsound minecraft:ambient.cave ambient @s ~ ~ ~ 0.7 0.7
