playsound minecraft:entity.player.breath ambient @s ~ ~ ~ 1.2 0.5
playsound minecraft:ambient.cave ambient @s ~ ~ ~ 1.0 0.6
playsound minecraft:entity.warden.ambient ambient @s ~ ~ ~ 0.8 0.5