kill @e[type=armor_stand,tag=horror_watcher]
execute at @s run summon armor_stand ^ ^ ^20 {Tags:["horror_watcher"],Invisible:1b,Invulnerable:1b,NoGravity:1b,ArmorItems:[{},{},{},{id:"minecraft:player_head",Count:1b,components:{"minecraft:profile":{properties:[{name:"textures",value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMTRiZDAzOTRiM2U0YTlhNmJjYTMxYzM4Y2UxZDM4NWQ4YTIzZmEzZGYwNTI1YWM3MWZkZjFjZTUxOGU1NWMxNCJ9fX0="}]}}}],ShowArms:0b,Small:0b}
execute as @e[type=armor_stand,tag=horror_watcher] at @s facing entity @p eyes run tp @s ~ ~ ~ ~ ~
execute as @e[type=armor_stand,tag=horror_watcher] run scoreboard players set @s watcher_life 160
playsound minecraft:entity.warden.heartbeat ambient @s ~ ~ ~ 0.8 0.5