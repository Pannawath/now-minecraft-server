playsound minecraft:entity.warden.nearby_closer ambient @s ~ ~ ~ 1.0 0.6
playsound minecraft:entity.player.breath ambient @s ^ ^ ^-1 1.5 0.4
effect give @s minecraft:slowness 2 0 true