# Apply subtle brief darkness & low sound
effect give @s minecraft:darkness 2 0 true
playsound minecraft:entity.warden.sniff ambient @s ~ ~ ~ 0.5 0.6
