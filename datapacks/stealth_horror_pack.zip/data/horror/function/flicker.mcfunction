effect give @s minecraft:darkness 4 0 true
playsound minecraft:entity.warden.sniff ambient @s ~ ~ ~ 1.0 0.5
playsound minecraft:ambient.cave ambient @s ~ ~ ~ 1.0 0.5