particle minecraft:smoke ~ ~1 ~ 0.3 0.6 0.3 0.05 35
playsound minecraft:entity.warden.heartbeat ambient @a[distance=..25] ~ ~ ~ 1.0 0.5
playsound minecraft:entity.enderman.teleport ambient @a[distance=..25] ~ ~ ~ 0.7 0.5
kill @s