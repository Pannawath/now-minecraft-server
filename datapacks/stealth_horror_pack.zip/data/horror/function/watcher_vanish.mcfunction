# Poof into smoke particles and low heartbeat
particle minecraft:smoke ~ ~1 ~ 0.25 0.4 0.25 0.03 20
playsound minecraft:entity.warden.heartbeat ambient @a[distance=..20] ~ ~ ~ 0.6 0.5
kill @s
