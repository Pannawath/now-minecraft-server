# 1: Watcher, 2: Whisper, 3: Flicker
execute if score #global horror_rng matches 1 run function horror:watcher
execute if score #global horror_rng matches 2 run function horror:whisper
execute if score #global horror_rng matches 3 run function horror:flicker
