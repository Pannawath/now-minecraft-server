# Random event selector: Watcher, Whisper, or Flicker
execute as @s at @s if predicate horror:chance_watcher run function horror:watcher
execute as @s at @s unless predicate horror:chance_watcher if predicate horror:chance_whisper run function horror:whisper
execute as @s at @s unless predicate horror:chance_watcher unless predicate horror:chance_whisper run function horror:flicker
