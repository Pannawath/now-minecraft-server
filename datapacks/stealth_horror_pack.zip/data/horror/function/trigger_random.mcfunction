execute if score #global horror_rng matches 1 run function horror:watcher
execute if score #global horror_rng matches 2 run function horror:whisper
execute if score #global horror_rng matches 3 run function horror:flicker
execute if score #global horror_rng matches 4 run function horror:jumpscare
execute if score #global horror_rng matches 5 run function horror:paranoia
execute if score #global horror_rng matches 6 run function horror:stalker_breath