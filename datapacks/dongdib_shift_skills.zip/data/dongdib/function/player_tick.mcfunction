# Player main tick loop
# Detect Shift press (Rising edge)
# d_is_sneak: 0 = unpressed previously, 1 = pressed previously

# Check current sneak state via predicate
scoreboard players set @s d_temp 0
execute if predicate dongdib:is_sneaking run scoreboard players set @s d_temp 1

# Rising edge: d_temp = 1 and d_is_sneak = 0
execute if score @s d_temp matches 1 if score @s d_is_sneak matches 0 run function dongdib:internal/shift_press

# Update previous sneak state
scoreboard players operation @s d_is_sneak = @s d_temp

# If mode is active (d_mode > 0)
execute if score @s d_mode matches 1..4 run function dongdib:internal/active_tick

# If charging (d_charge > 0 and d_mode matches 0)
execute if score @s d_charge matches 1..9 if score @s d_mode matches 0 run function dongdib:internal/charge_tick
