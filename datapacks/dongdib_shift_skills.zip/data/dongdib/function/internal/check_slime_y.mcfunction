# Only set mode 3 if player Y < 40
execute at @s if entity @s[y=-64..39] run scoreboard players set @s d_temp 3
