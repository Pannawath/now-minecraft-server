# Determine held item category for player
# mode 0: none/invalid
# mode 1: Axe
# mode 2: Seed (wheat, carrot, potato, beetroot)
# mode 3: Slime block (and Y < 40)
# mode 4: Torch

scoreboard players set @s d_temp 0

# Check Axe
execute if items entity @s weapon.mainhand #minecraft:axes run scoreboard players set @s d_temp 1

# Check Seeds
execute if items entity @s weapon.mainhand minecraft:wheat_seeds run scoreboard players set @s d_temp 2
execute if items entity @s weapon.mainhand minecraft:carrot run scoreboard players set @s d_temp 2
execute if items entity @s weapon.mainhand minecraft:potato run scoreboard players set @s d_temp 2
execute if items entity @s weapon.mainhand minecraft:beetroot_seeds run scoreboard players set @s d_temp 2
execute if items entity @s weapon.mainhand minecraft:pumpkin_seeds run scoreboard players set @s d_temp 2
execute if items entity @s weapon.mainhand minecraft:melon_seeds run scoreboard players set @s d_temp 2
execute if items entity @s weapon.mainhand minecraft:torchflower_seeds run scoreboard players set @s d_temp 2
execute if items entity @s weapon.mainhand minecraft:pitcher_pod run scoreboard players set @s d_temp 2

# Check Slime Block (Y < 40)
execute if items entity @s weapon.mainhand minecraft:slime_block run function dongdib:internal/check_slime_y

# Check Torch
execute if items entity @s weapon.mainhand minecraft:torch run scoreboard players set @s d_temp 4
