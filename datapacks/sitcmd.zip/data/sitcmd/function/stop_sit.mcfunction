# Stop Sit
tag @s remove is_sitting
execute at @s as @e[type=interaction,tag=sit_entity,distance=..2] run kill @s