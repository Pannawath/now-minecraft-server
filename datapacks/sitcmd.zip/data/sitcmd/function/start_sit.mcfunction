# Start Sit
scoreboard players reset @s sit
tag @s add is_sitting
summon interaction ~ ~-0.3 ~ {Tags:["sit_entity"]}
ride @s mount @e[type=interaction,tag=sit_entity,limit=1,sort=nearest,distance=..1]
playsound minecraft:item.bundle.insert player @s ~ ~ ~ 0.8 0.8
