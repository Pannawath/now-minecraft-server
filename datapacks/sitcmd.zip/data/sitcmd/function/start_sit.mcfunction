# Start Sit
scoreboard players reset @s sit
tag @s add is_sitting
execute at @s run summon interaction ~ ~0.25 ~ {Tags:["sit_entity"]}
execute at @s run ride @s mount @e[type=interaction,tag=sit_entity,limit=1,sort=nearest,distance=..1]
playsound minecraft:item.bundle.insert player @s ~ ~ ~ 0.8 0.8