# Sit Load
scoreboard objectives add sit trigger
