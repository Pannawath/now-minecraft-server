# Sit Tick
scoreboard players enable @a[tag=!is_sitting] sit
execute as @a[tag=!is_sitting] if score @s sit matches 1.. at @s run function sitcmd:start_sit
execute as @a[tag=is_sitting] unless data entity @s RootVehicle.Entity run function sitcmd:stop_sit
