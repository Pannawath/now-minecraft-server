execute as @a[advancements={minecraft:recipes/redstone/hopper=true}] run recipe give @s super_hopper:super_hopper
execute as @a[scores={super_hoper_place=1..}] at @s run function super_hopper:placed
scoreboard players set @a super_hoper_place 0
execute as @e[type=minecraft:marker,tag=super_hopper] at @s run function super_hopper:reset_cooldown
schedule function super_hopper:tick 1t replace