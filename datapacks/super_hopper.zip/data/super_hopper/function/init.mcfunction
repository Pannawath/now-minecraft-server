scoreboard objectives add super_hoper_place minecraft.used:minecraft.hopper
schedule function super_hopper:tick 1t replace