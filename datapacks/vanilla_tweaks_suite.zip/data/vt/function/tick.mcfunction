# VT AFK Display & Armor Statues
# Cauldron Concrete conversion
execute as @e[type=item] at @s if block ~ ~ ~ minecraft:water_cauldron[level=3] if entity @s[nbt={Item:{id:"minecraft:white_concrete_powder"}}] run summon item ~ ~ ~ {Item:{id:"minecraft:white_concrete",Count:1b}}
