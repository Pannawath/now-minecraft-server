execute if score #custom_block_ext.patch load.status matches ..0 unless score #custom_block_ext.patch load.status matches 0 run function custom_block_ext:v0.3.0/test_load/enumerate/set_version
