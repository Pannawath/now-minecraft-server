scoreboard players set #custom_block_ext.major load.status 0
scoreboard players set #custom_block_ext.minor load.status 3
scoreboard players set #custom_block_ext.patch load.status 0
scoreboard players set #custom_block_ext.set load.status 1
