scoreboard players reset #custom_block_ext.set load.status
scoreboard players add #custom_block_ext.major load.status 0
scoreboard players add #custom_block_ext.minor load.status 0
scoreboard players add #custom_block_ext.patch load.status 0
function custom_block_ext:v0.3.0/test_load/enumerate/major
