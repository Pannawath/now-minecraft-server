schedule clear custom_block_ext:v0.3.0/tick
execute if score #custom_block_ext.major load.status matches 0 if score #custom_block_ext.minor load.status matches 3 if score #custom_block_ext.patch load.status matches 0 run function custom_block_ext:v0.3.0/test_load
